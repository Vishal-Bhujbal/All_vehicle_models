# **Guide to start the app**



##### Follow the following steps to install the app:





1. Open Prep\_tire\_data.m.
2. Navigate to the folder where you extracted the zip file.
3. Select the mrf.tir file - right click - copy as path.
4. Paste it in front of filename in the script of Prep\_tire\_data.m.
5. Run the start.m file first.
6. Wait for the vehicle\_model\_1000 to open.......
7. Open the release folder from the zip file.
8. double click on the app12.
9. Install the app.



##### Follow the following steps to run the app:



1. Run the start.m file first.
2. Wait for the vehicle\_model\_1000 to open.......
3. Search for app12 in matlab apps an open it.
