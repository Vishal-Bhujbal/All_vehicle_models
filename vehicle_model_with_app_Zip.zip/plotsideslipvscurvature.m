function results = plotsideslipvscurvature(modelName)
% =========================================================================
% FUNCTION: plotCurvatureVsSteer_MultiV
% Purpose:
%   Runs the simulation for multiple velocities and stores curvature vs
%   steering data for each velocity.
%
% Output:
%   results: struct array with fields:
%     - v     : velocity (m/s)
%     - s_deg : steering angle (deg)
%     - kappa : curvature (1/m)
% =========================================================================

    if ~bdIsLoaded(modelName)
        load_system(modelName);
    end

    StopTime   = '20';
    Solver     = 'ode23s';
    t_start    = 10;

    % Preallocate struct
    results = repmat(struct('steer',[],'sideslip', [], 'kappa', []), 1);  
    % Kappa is curvature..

    for steer_angle = pi/6
        

        % --- Simulation Input ---
        simIn = Simulink.SimulationInput(modelName);
        simIn = simIn.setModelParameter('StopTime', StopTime);
        simIn = simIn.setModelParameter('Solver', Solver);
        simIn = simIn.setVariable('steer_angle', steer_angle);

        % --- Run simulation ---
        out = sim(simIn);

        % --- Fetch curvature + steer ---
        kappa_ts = timeseries(out.curvature.Data,out.curvature.Time);
        vx = out.vx.Data;
        vy = out.vy.Data;
        sideslip_ts = timeseries(vy./vx,out.vx.Time);
        steer_ts = timeseries(out.steer_input.Data*(180/pi),out.steer_input.Time);

        % Ensure timeseries format
        % if ~isa(kappa_ts,'timeseries')
        %     kappa_ts = timeseries(kappa_ts.Data, kappa_ts.Time);
        % end
        % if ~isa(steer_ts,'timeseries')
        %     steer_ts = timeseries(steer_ts.Data, steer_ts.Time);
        % end

        % Trim after 10 sec
        kappa_ts = getsamples(kappa_ts, kappa_ts.Time >= t_start);
        steer_ts = getsamples(steer_ts, steer_ts.Time >= t_start);
        sideslip_ts = getsamples(sideslip_ts,sideslip_ts.Time >= t_start);

        % Resample steering to curvature time base
        % t_common = kappa_ts.Time;

        % Store in results
        results.steer = steer_ts;
        results.sideslip = sideslip_ts;
        results.kappa = kappa_ts.Data;
    end
end


plotsideslipvscurvature("vehicle_model_1000")
