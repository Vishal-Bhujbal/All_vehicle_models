% Function to plot handling curve i.e. Difference between steering angles
% against lateral acceleration ay.
function results3 = plot_handling_curve(modelname)

    if ~bdIsLoaded(modelname)
        load_system(modelname);
    end

    StopTime   = '20';
    Solver     = 'ode23s';

    % Preallocate struct
    results3 = repmat(struct('steer_L',[],'steer_R', [], 'ay', [], 'time', []), 1); 

    % Simulation input setup
    simIn = Simulink.SimulationInput(modelname);
    simIn = simIn.setModelParameter('StopTime', StopTime);
    simIn = simIn.setModelParameter('Solver', Solver);    
    % Run the simulation
    out = sim(simIn);

    % Fetch steering angle and lateral acceleration data.

    steer_L = timeseries(out.steer_L.Data,out.steer_L.Time);
    steer_R = timeseries(out.steer_R.Data,out.steer_R.Time);
    ay = timeseries(out.ay_sensor.Data,out.ay_sensor.Time);

    % Populate the empty structure results3
    results3.steer_L = steer_L.Data;
    results3.steer_R = steer_R.Data;
    results3.ay = ay.Data;
    results3.time = ay.Time;

end




