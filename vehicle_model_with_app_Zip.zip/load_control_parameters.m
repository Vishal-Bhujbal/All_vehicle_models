% Torque Vectoring Gains
TV_on = 1;
% TV_vx_breakpoints= [7 11 15 19 23 27 31 35];
% TV_Kp = [8006.9886 10801.0139 12104.8923 12859.7693 13352.0804 13698.5216 13955.5585 14153.8442];
% TV_Ki = [72973.9929 245952.3897 332632.3625 384548.0689 419090.6486 443722.3350 462170.3852 476502.3895];
% TV_vx_breakpoints = [7 10 13 16 19 22];
% TV_Kp = [296.29 392.23 421.72 479.87 396.22 404.79];
% TV_Ki = [12716.7 12492.5 12040 11536.07 11058.5 13650];
%Traction Control Gains
TC_on = 1;
TC_target_slip = 0.07;
TC_breakpoints = [0,1];
TC_Kp = [0,0];
TC_Ki = [0,0];
TC_Kd = [0,0];

cf = 35238.459;
cr = 35033.582;
lf = 0.75215;
lr = 0.78285;
m = 270;
izz = 47.563;
h = 0.205;
gr = 10.05;
rw = 0.2286;
ku = (lr*m/(cf*(lf+lr))) - (lf*m/(cr*(lf+lr)));

vx_breakpoints = 1 : 0.5 : 40; 
TV_vx_breakpoints = vx_breakpoints;

Kp_data = zeros(size(vx_breakpoints));
Ki_data = zeros(size(vx_breakpoints));


for i = 1:length(vx_breakpoints)
    v_curr = vx_breakpoints(i); 
    
    
    A = [-(cf +cr)/(m*v_curr), ((-lf*cf) + (lr*cr))/(m*v_curr) - v_curr ;  ((-lf*cf) + (lr*cr))/(izz*v_curr), -((lf^2*cf) + (lr^2*cr))/(izz*v_curr)];
    B = [ cf/(m*v_curr),0;lf*cf/izz, 1/(izz)];
    C = [1 0;0 1];
    D = [0 0;0 0];
    
    a1 = A(1,1); a2 = A(1,2);
    a3 = A(2,1); a4 = A(2,2);
    b4 = B(2,2); 
    b2 = B(1,2); 
    
    k1 = b4;
    k2 = b2*a3 - a1*b4;
    k3 = -(a1+a4);
    k4 = (a1*a4) - (a2*a3);
    
    Kp_val = (40 + 289.89 - k3)/k1;
    Ki_val = ((40*289.89 + 839.89 - k4 -(k2*Kp_val))/k1);
    
    Kp_data(i) = Kp_val;
    Ki_data(i) = Ki_val;
end 
    TV_Kp = Kp_data;
    TV_Ki = Ki_data;
    TV_Kd = zeros(size(vx_breakpoints));

